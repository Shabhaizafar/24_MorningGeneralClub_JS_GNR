//

// console.log(a);
// a = 12;
// console.log(a);

// Global Scope :
// globally Value : changable/(can redeclare)/(possible to use without assign Value) : var 
// globally Value : changable/(cann't redeclare) /(possible to use without assign Value): let  
//Memory : global Memory
// globally Value : not Changable/(cann't redeclare)/(Must be Assign Value) : const
//Memory : global Memory
    //Object declare : const 


// Block Scope : (Doesn't Effect Global Scope//that means they are not Accessable in Global Scope)
// Must  :  let(Moslty),const(rarly)
// Function Scope :  (Temp)   // lexical  
// (Doesn't Effect Global Scope//that means they are not Accessable in Global Scope)

// local Value : changable/(can redeclare)/(possible to use without assign Value) : var 
// local Value : changable/(cann't redeclare) /(possible to use without assign Value): let
// local Value : not Changable/(cann't redeclare)/(Must be Assign Value) : const
    //Object declare : const 

// globally : var keyword : this object/window Object







// function All(){

// }

var All = function (){

}



// var declarations are hoisted and initialized to undefined.
// let and const declarations are hoisted but remain uninitialized, leading to a ReferenceError if accessed before declaration.
// Function declarations are hoisted with their implementation, so they can be called before their definition in the code.
// Function expressions are hoisted as undefined if assigned to a variable, so they cannot be called before their definition.