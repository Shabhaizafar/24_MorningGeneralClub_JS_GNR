// var a = 12;
// let b = 13;
// const c = 14;
// console.log(a); //12
// console.log(b); //13
// console.log(c); //14
// // console.log(d); //und
// console.log(e); //err //und 
// let d = 160;
// const e = 1;


// var n1 = 12;
// var n2 = 13;
// console.log("Value of First n1 : ",n1);
// console.log("Value of First n2 : ",n2);
// function All(a,b){
//     function Inner1(x,y){
//         console.log(n1);
//         function Inner2(){
//             var n1 = 100;
//             var n2 = 200;
//             console.log(n1);
//             console.log(n2);
//         }
//         Inner2();
//         return x+y;
//     }
//     return Inner1(a,b);
// }
// var ans = All(n1,n2);
// console.log(ans);


// var a = 13;
// let b = 14;
// const c = 15;
// function Main(x,y,z){
//     console.log("Value X : ",x);
//     console.log("Value Y : ",y);
//     console.log("Value Z : ",z);
//     var Arrowfu = (l,m,n)=>{
//         console.log("Value L : ",l);
//         console.log("Value M : ",m);
//         console.log("Value N : ",n);
//         this.x = 300;
//     }
//     this.a = 100;
//     this.b = 200;
//     console.log("Value X : ",x);
//     return Arrowfu(x,y,z);
// }
// var ans = Main(a,b,c);
// console.log("Value ANS : ",ans);
// console.log("Value a : ",a);
// console.log("Value b : ",b);
// console.log("Value c : ",c);



// note Book : 
// what is a Global Scope ? with example and Explaination.
// what is a block Scope ? with example and Explaination.
// what is a function Scope ? with example and Explaination.
// what is a lexical Scope ? with example and Explaination.








// console.log(a);
// let a = 12;
// console.log(13);
// // var a = 12;
// // console.log(a);


