// function All(fname,lname){
//     this.firstname = fname;
//     this.lastname = lname;
// }

// All.prototype.greet  = function (){
//         console.log(`Your Name is ${this.firstname} ${this.lastname}.`);
// };

// var obj1 =new All("Raj","Patel");
// var obj2 =new All("Ajay","Shah");

// console.log(obj1);
// console.log(obj2);

// obj1.greet();
// obj2.greet();
////////////////////////////////
// Methods  :

// class All{
//     constructor(fname,lname){
//         this.firstname = fname;
//         this.lastname = lname;   
//     }
//     greet = function (){
//         console.log(`Your Name is ${this.firstname} ${this.lastname}.`);
//     }
// }



// var obj1 =new All("Raj","Patel");
// var obj2 =new All("Ajay","Shah");

// console.log(obj1);
// console.log(obj2);

// obj1.greet();
// obj2.greet();

/////////////////////////////////////////////////////////////////////////
// / Constructor Functions
// Basic Constructor:

// Define a constructor function named Book that takes title and author as parameters. Add a method to the prototype that returns a string in the format: "Title by Author".
// Object Creation:

// Create three Book objects with different titles and authors. Store these objects in an array called library. Write a function to log the description of each book in the library array.
// Prototype Method:

// Add a prototype method isAuthor to the Book constructor function that takes an author parameter and returns true if the book’s author matches the given author, otherwise returns false.


////////////////////////////////
// ES6 Classes
// Basic Class:

// Define a class named Car with a constructor that accepts make, model, and year. Add a method getDetails that returns a string in the format: "Make Model, Year".
// Creating Objects:

// Instantiate three Car objects with different makes, models, and years. Store these objects in an array called garage. Write a method in the Car class that logs the details of each car in the garage array.

