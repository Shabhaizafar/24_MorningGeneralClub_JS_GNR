function All(){
    console.log("Hello Everyone !!!");
}
All();


All.Fname = "Raj";

console.log(All.Fname);

console.log(All.prototype);   //{} = object literal



// var obj = { 
//     fname : 'Raj'
// };
// console.log(obj);

// obj.Gender = "Male";
// obj['lname'] = 'Patel';
// console.log(obj);