var o1 = {
    fname : "Raj",
    lname : "Shah"
};

console.log(o1.__proto__);


// var o2 = Object.create(o1);

// o2.Age = 13;

// console.log(o1);
// console.log(o1.fname);

// console.log(o2);
// console.log(o1);

// console.log(o2.Age);


// console.log(o2.fname);  



// Object : Extra Space : 
// proto : {}






// console.log(o2.__proto__);
// console.log(o2[[prototype]]);




// __proto__ (Use in a Program) === [[prototype]] (Browser Display)

// [[prototype]] != prototype

// __proto__ != prototype
