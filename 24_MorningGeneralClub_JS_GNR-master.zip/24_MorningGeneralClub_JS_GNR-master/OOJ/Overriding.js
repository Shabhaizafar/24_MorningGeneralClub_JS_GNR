// Method Overriding : 

// var fname = "Raj";
// var lname = "Patel";
// const Person = {
//     fname : "ajay",
//     lname : "Shah",
//     fullName  : function (){
//         console.log(`Hello My Name is ${this.fname} ${this.lname}.`);
//     }
// }

// console.log(Person);
// Person.fullName();


// Person.fullName = () =>{
//     console.log(`Hello My Name is ${this.fname} ${this.lname}.`);
// }
// Person.fullName();


