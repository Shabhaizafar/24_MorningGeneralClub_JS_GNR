// console.log(document);
// // console.log(Document);


// console.log(typeof document);

// console.log(document.head);
// console.log(document.body);
// console.log(document.h2);//undefined
// console.log(document.body.h2);



//1) using Id.
// #heading1
// console.log(document.getElementById('heading1'));

// 2) using class.
// console.log(document.getElementsByClassName('class1'));

// console.log(Array.isArray(document.getElementsByClassName('class1')));
// console.log(document.getElementsByClassName('class1')[0]);
// console.log(document.getElementsByClassName('class1')[1]);

// 3) using tag name

// console.log(document.getElementsByTagName('h2'));
// console.log(document.getElementsByTagName('h2')[0]);
// console.log(document.getElementsByTagName('h2')[1]);
// console.log(document.getElementsByTagName('h2')[2]);//undefined 








//4) querySelector
//5) querySelectorAll