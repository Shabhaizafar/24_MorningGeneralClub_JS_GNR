// const btns = document.querySelectorAll('button');
// console.log(btns);
// console.log(btns[0]);

// btns[0].onclick = function (){
//     btns[0].style.backgroundColor = "lime";
// }

// function fun2(){
//     btns[1].style.backgroundColor = "skyblue";
// }

// function fun3(){
//     btns[2].style.backgroundColor = "coral";
// }
// function fun4(){
//     btns[3].style.backgroundColor = "purple";
// }
// function fun5(){
//     btns[4].style.backgroundColor = "crimson";
// }
// function fun6(){
//     btns[5].style.backgroundColor = "brown";
// }
// function fun7(){
//     btns[6].style.backgroundColor = "black";
// }
// function fun8(){
//     btns[7].style.backgroundColor = "black";
// }

/*
wheel 
*/ 


// const body = document.body;
//             // event : abc
// body.onkeydown = function (event){
//     // console.log("down");
//     // console.log(event.key);
//     console.log(event['key']);
// }

// body.onkeypress = function (){
//     console.log('Press');
// }
// body.onkeyup = function (){
//     console.log('Up');
// }
// body.onkeydown = function (){
//     console.log('Down');
// }