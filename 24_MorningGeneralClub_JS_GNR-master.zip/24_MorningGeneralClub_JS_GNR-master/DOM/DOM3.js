// innerHTML
// innerText
// textContent

// Using Tag Name
console.log(document.querySelector('article'));

// Using Class Name 
console.log(document.querySelector('.content2'));

// Using ID name
console.log(document.querySelector('#content3'));



// console.log(document.querySelector('h6').innerHTML);
// console.log(document.querySelector('h6').innerText);
// console.log(document.querySelector('h6').textContent);



console.log(document.querySelector('article').innerHTML);

console.log(document.querySelector('article').innerText);

console.log(document.querySelector('article').textContent);

