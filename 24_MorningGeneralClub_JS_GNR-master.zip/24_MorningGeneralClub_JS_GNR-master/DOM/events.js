// const btn1 = document.querySelector('.btn1');
// const btn2 = document.querySelector('.btn2');
// const btn3 = document.querySelector('.btn3');
// const btn4 = document.querySelector('.btn4');
// const btn8 = document.querySelector('.btn8');
// const btn5 = document.querySelector('.btn5');
// const btn6 = document.querySelector('.btn6');
const btn9 = document.querySelector('.btn9');


// btn1.onclick = function (){
//     document.body.style.backgroundColor = 'red';
//     btn1.classList.add("animation");
//     console.log(btn1.classList);
// }

// //Anonymous
// btn2.onmouseover = function (){
//     document.body.style.backgroundColor = 'red';
// }

// btn3.onmouseleave = function (){
//     document.body.style.backgroundColor = 'blue';
// }


// btn4.onmousedown = function (){
//     document.body.style.backgroundColor = 'yellow';
// }

// btn8.onmouseup = function (){
//     document.body.style.backgroundColor = 'lime';
// }

// btn5.onmouseenter = function (){
//     document.body.style.backgroundColor = 'purple';
// }

// btn6.onmousemove = function (){
//     document.body.style.backgroundColor = 'gray';
// }



/////////////////////
// const div = document.querySelector('div');
// div.onmouseenter = function (){
//     div.style.backgroundColor = "navy";    
// }


// overmouseover vs onmouseenter



// overmouseleave vs onmouseout

// overmousewheel      // wheel  
btn9.onmousewheel = function (){
    console.log("Trigger");
    div.style.backgroundColor = "red";
}


