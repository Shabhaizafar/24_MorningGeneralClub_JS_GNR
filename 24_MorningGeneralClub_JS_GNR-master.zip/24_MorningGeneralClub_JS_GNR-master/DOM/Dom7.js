const body = document.querySelector('body');
const div = document.querySelector("div");
const h1 = document.querySelector("h1");

// console.log(div);
// console.log(h1);

//Event : 
// div.onclick = function(){
//     div.style.backgroundColor = "navy";
//     console.log("div");
// }

// h1.onclick = function(){
//     div.style.backgroundColor = "red";
//     console.log("h1");
// }


// Ounter Function 
// function All(){
//     console.log("sertyu");
// }

// div.addEventListener('click',All);



// div.addEventListener('click',function (){
//     console.log("awerty");
// });



// div.onclick = function(){
//     console.log("div1");
// }
// div.onclick = function(){
//     console.log("div2");
// }



// div.addEventListener('click',function (){
//     console.log("Div1");
// });

// div.addEventListener('click',function (){
//     console.log("Div2");
// });


/////////////////////////////////////////////////////
// body.addEventListener('click',function (){
//     console.log("body");
// },true);

// div.addEventListener('click',function (){
//     console.log("div");
// },true);
// h1.addEventListener('click',function (){
//     console.log("h1");
// },false);

// bubbling,capturing,