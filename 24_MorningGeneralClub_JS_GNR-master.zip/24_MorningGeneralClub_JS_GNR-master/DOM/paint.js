const body = document.querySelector('body');
const allbtn = document.querySelectorAll('.clr button');
var counter = 0;
console.log(allbtn);

body.addEventListener('click',function (event){
    allbtn.forEach(
        (v)=>{
            if(v==event.target)
                counter = 1;     
        }
    );
    if(counter==1){
        console.log(event.target.classList.toggle('border'));
    }
    counter=0;
});


document.querySelector('.pencil').onclick = function (){
    document.body.classList.add('cursor');
}