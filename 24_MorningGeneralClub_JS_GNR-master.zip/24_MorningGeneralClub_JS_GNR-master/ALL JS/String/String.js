// "use strict";
// fname = "Zafar";
// console.log(fname);
// var 
// let 
// const
///////////////////////////////////////////
// /String/
// What is a String : Collection of Multiple Char. 
            // String not an Array but it's similler an Array.

// using Double Quotation
//length      12345
// var Str = "Royal";
// //index    01234
// console.log(Str);

// // using Single Quotation
// var Str2 = 'Technosoft';
// console.log(Str2);

// // using Back-tick
// var Str3 = `p ltd`;
// console.log(Str3);

// console.log(Str[2]);

// /Methods of String/
//1) length : 
// console.log(Str.length);

// console.log(Str[Str.length-1]);



// var str = "Royal Technosoft p ltd";
// console.log(str);
// console.log(str.length);

//1) str.charAt
                        // index
// console.log(str.charAt(21));

//2) str.charCodeAt
                        //index
// console.log(str.charCodeAt(0));

//3) str.concat
// var str2 = "Gandhinagar"
// console.log(str.concat(".",str2));


//////////////////////////////////////////////////////
/24-04-2024/
var str = "Royal Technosoft p ltd";
console.log(":",str);
//4) str.endsWith
// console.log(str.endsWith('p ltd')); //return true or false 

//5) str.startsWith
// console.log(str.startsWith("Royal")); //return true or false 

//6) str.includes
// console.log(str.includes("Tech")); //return true or false 

//7) str.indexOf
// console.log(str.indexOf("Tech"));

//8) str.lastIndexOf
// console.log(str.lastIndexOf("Tech"));

//9) str.replace
// console.log(str.replace("Tech","TECH"));

//10) str.replaceAll
// console.log(str.replaceAll("o","A"));

//11) str.split
// console.log(str.split(''));

//12) str.toLowerCase
// console.log(str.toLowerCase());


//13) str.toUpperCase
// console.log(str.toUpperCase());

//14) str.trim
// console.log(str.trim());


//15) str.trimEnd
// console.log(str.trimEnd());

//16) str.trimStart
// console.log(str.trimStart());

//17) str.valueOf
// console.log(str.valueOf());



// str.slice
        //1) starting index 2) ending index
// console.log(str.slice(10,5));
// str.substring
        // starting index and ending index
// console.log(str.substring(10,5));
// str.substr

                //1) starting point(index)   2) length
// console.log(str.substr(5,10));




//1) write in a Note - pen 
//https://quizzesforyou.com/quiz/jsstring#google_vignette