// - Template Strings.
var fname = "Ajay";
var lname = "Patel";
var Age = 13;


// My name is Raj Patel.and My Age is 13 year old.

console.log("My name is Raj Patel.and My Age is 13 year old.");
// console.log("My name is",fname,lname,".and My Age is",Age,"year old.");
// console.log("My name is "+fname+" "+lname+".and My Age is"+Age+"year old.");



console.log(`My name is ${fname} ${lname}.and My Age is ${Age} year old.`);