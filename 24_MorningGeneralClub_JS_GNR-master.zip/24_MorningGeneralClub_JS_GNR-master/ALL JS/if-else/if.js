// if statement : 


// adult ?    

// var age = 10;
// if (age>=18) {
//     console.log("You are Adult😃.");
// }



//if-else Statement : 

// adult or not ?
// age = 18;
// if (age>=18) {
//     console.log("You are Adult😃.");
// }
// else
// {
//     console.log("You are Not Adult😅.");
// }

// else if Statement :

//  number Positive/Negative/Zero ?

// var n1 = -10;
// if(n1>0)
// {
//     console.log("N1 is Positive.");
// }
// else if(n1==0){
//     console.log("N1 is Zero.");
// }
// else{
//     console.log("N1 is Negative.");
// }

// nested if-else 
//Leap Year or Not  ? 
// var year = 1900;  //1900

// if(year%4==0)
// {
//     if(year%100==0)
//     {
//         if(year%400==0)
//         {
//             console.log("Leap Year after divided 400.");
//         }
//         else
//         {
//             console.log("Not Leap Year after not divided 400");
//         }
//     }
//     else
//     {
//         console.log("Leap Year after not divided 100.");
//     }
// }
// else
// {
//     console.log("Not Leap Year after not divided 4.");
// }

// if((year%4==0 && year%100!=0 ) ||  (year%400==0 && year%100==0))

// if(year%4==0 && (year%100!=0 || year%400==0) )
// {
//     console.log("leap year");
// }
// else
// {
//     console.log("Not Leap Year");
// }

// %4==0   leap or not leap 
//     year%100==0   

//     else 
//         not leap 
// not leap


// 100 200 300 400 


// a + (b-c) 

// (a+b)-(a+c)


///////////////////////////////
// 2. Write a JavaScript conditional statement to find the sign of the product of three numbers. Display an alert box with the specified sign.
// Sample numbers : 3, -7, 2
// Output : The sign is -

// + 
// -


// 4. Write a JavaScript conditional statement to find the largest of five numbers. Display an alert box to show the results.
// Sample numbers : -5, -2, -6, 0, -1
// Output : 0


// *
// * *
// * * *
// * * * *