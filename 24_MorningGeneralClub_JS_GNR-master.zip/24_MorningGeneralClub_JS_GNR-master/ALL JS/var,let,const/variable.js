// var fname = "Royal";
// console.log(fname);
// // fname = "Techno";
// // console.log(fname);
// var fname = 12;
// console.log(fname);





// let fname2 = "Royal2";
// console.log(fname2);
// // fname2 = "Tehno2";
// // console.log(fname2);
// // let fname2 = "Dhruv";//error


// const fname3 = "Royal3";
// console.log(fname3);
// // fname3 = "Techno3";
// // console.log(fname3);//error

// // const fname3 = "asd";//error





// console.log(fname);
// const fname = "a";

