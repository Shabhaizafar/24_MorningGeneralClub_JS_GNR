// - recurssion Function 
// var i = 1;
// function Hello(){
//     console.log(i++);
// }
// Hello();
// var fact = 1;
// var n = 5;
// for (let i = 1; i <=n; i++) {
//     fact=fact*i;
// }
// console.log(fact);

// var fact = 1;
// function Factorial(n){
//     if(n==0)
//         {
//             return fact;
//         }
//         fact= fact*n;
//     return Factorial(n-1);
// }
// console.log("Factorial : ",Factorial(5));

/*
// --------------------------------------
Fibonacci Sequence

Write a function fibonacci(n) that returns the nth number in the Fibonacci sequence.
// ------------------------------
String Reversal

Write a function reverseString(str) that returns the reversed version of a given string.
// ---------------------------------
Binary Search

Write a function binarySearch(arr, target) that implements the binary search algorithm using recursion to find the index of target in a sorted array arr.
// ----------------------------------
N-Queens Problem

Write a function solveNQueens(n) that solves the N-Queens problem and returns one possible solution.
// -------------------------------------
Tower of Hanoi

Write a function towerOfHanoi(n, fromRod, toRod, auxRod) that solves the Tower of Hanoi problem for n disks.
// ------------------------------------
Merge Sort

Write a function mergeSort(arr) that sorts an array using the merge sort algorithm.
// --------------------------------------
Quick Sort

Write a function quickSort(arr) that sorts an array using the quick sort algorithm.
// -------------------------------------
*/ 