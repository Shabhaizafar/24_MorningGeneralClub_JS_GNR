// // - What is Function : 
// // - A JavaScript function is a block of code designed to perform a particular task.
// // - A JavaScript function is executed when "something" invokes it (calls it).


// //Types of Function : 
// // - Name Function 
//     // - without arg and without rtn type 
//     // - with arg and without rtn type 
//     // - without arg and with rtn type 
//     // - with arg and with rtn type 

// // - Expression Function
//     // - without arg and without rtn type 
//     // - with arg and without rtn type 
//     // - without arg and with rtn type 
//     // - with arg and with rtn type 

// // - Arrow Function
//     // - without arg and without rtn type 
//     // - with arg and without rtn type 
//     // - without arg and with rtn type 
//     // - with arg and with rtn type 

// // - Anonymous Function
// // - IIFE Function
// // - Generator Function 
// // - callback Function
// // - recurssion Function 
// // - Higher Order Function 
// // - geter-seter Function  (oo)
// //////////////////////////////////////////////////////
// /Name Function/
// /*
// //Function declaration and Initialization
// function Function_Name(){
//     code;
// }
// //Function Calling
// Function_Name();  
// */
// //1) without arg and without rtn type 
// //Function declaration and Initialization
// function Hello(){
//     console.log("Hello Everyone!!, Welcome to JS World!!😍");
// }

// // Hello();//Function calling(invoke)

// //2) with arg and without rtn type 
// function Addition(n1,n2){  //perameter : n1,n2
//     console.log("Addition is : ",n1+n2);
//     // console.log(typeof n1);
//     // console.log(typeof n2);
// }

// // Addition(12,13);//Argument : 12,13

// //3) without arg and with rtn type 
// // function GiveMe_Somthing(){
// //     return "Hello Everyone!!, Welcome to JS World!!😍";   // return
// // }
// // var ans = GiveMe_Somthing();
// // console.log(ans);

// //4) with arg and with rtn type.
// // function Result(n1){
// //     if(n1>33)
// //     {
// //         return "You are Pass🤩.Give me Party😋.";
// //     }
// //     else
// //     {
// //         return "You are Fail😥.Batter Luck next Time😃.";
// //     }
// // }
// // var output = Result(20);
// // console.log(output);



// // //////////////////////////////////////////////////
// // 1)  wap to check given input is Pelindrome or not. (using with arg and without rtn type) (string/number)
// // 2) wap to check given number is Perfect or Not. (using with arg and with rtn type) 