// Arrow Function 
// var variable =  () =>{

// }

//- without arg and without rtn 

// var Arrow1 = ()=>{
//     console.log("Hello Everyone!!");
//     for (let i = 0; i < 10; i++) {
//         console.log(i);
//     }
// }

// Arrow1(); //calling/invoke

//- with arg and without rtn 
// var Arrow2 = (n1,n2)=>{   //n1,n2  : perameter
//     console.log(n1+n2);
// }

// var n1  = 13;
// var n2 = 12;
// Arrow2(n1,n2); // 12 ,13 Arg   //n1,n2 Arg

// Arrow2(100,200);

//- without arg and with rtn 
// var Arrow3 = ()=>{



//     return "ASDFghjkl";
// }

// console.log(Arrow3());
// var ans = Arrow3();
// console.log(ans);


//- with arg and with rtn 

// var Arrow4 = (n)=>{
//     if(n>0)
//         {
//             return "Positive";
//         }
//     else if(n==0){
//             return "Zero";
//         }
//     else{
//         return "Negative";
//     }
// }
// console.log(Arrow4(-10));