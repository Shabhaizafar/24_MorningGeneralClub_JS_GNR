//Generator Function : 
// Syntax : 
/*
1) function *function_name(){

}

2)function* function_name(){

} 

3)function*function_name(){

}
*/
//function declration/initialization
// function *Generatorfu(){
//     yield 1;
//     yield 2;
//     yield 3;
//     yield 4;
//     yield 5;
// }
// var output = Generatorfu();
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());


/////////////////////////////////
// Create a generator that yields the characters of a given string one by one.
// Write a generator function to yield prime numbers up to a given limit.