document.write("Hello");
console.log("Hello2");


// comment in a  JS 

// Single line Comment 


/*
Multi
Line
Comments
*/ 