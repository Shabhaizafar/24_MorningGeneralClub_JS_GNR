// - Intro to objects : 
//  pair  : key +value      = property
// - methods :


// Create a Empty Object
// var myobj = {};
// console.log(myobj);

// console.log(typeof myobj);



// //
// var Person = {
//     lname : "Shah", 
//     fname : "Raj",
//     1 : "Hello"
// }


// //How to Access  Object 
// console.log(Person);


//How to Access Property Value.
// 1) using Dot Notation 
// console.log(Person.fname);

// // 2) using Bracket Notation 
// console.log(Person['1']);
// console.log(Person["lname"]);
// console.log(Person[`fname`]);


//How To Modify/Update Property Value.

//1) using Dot Notation 
// Person.lname = "Patel";

// //2) using Bracket Notation 
// Person['fname'] = "Ajay";







// Wap to convert Array in reverse Order also add array in  new Variable.then print both Array.
