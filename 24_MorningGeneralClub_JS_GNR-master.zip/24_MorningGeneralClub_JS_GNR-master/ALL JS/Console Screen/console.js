// console.log("Hello");


// print data 
// console.log(12);
// console.log([1,2,3,4,5,6,7,8,9,1,2,3,4,5,5]);


// print data in a table form
// console.table([1,2,3,4,5,6,7,8,9,1,2,3,4,5,5]);



// given error msg
// greater   13   >   13     error
// console.error("Please enter Greater Number");


//given warning msg 
// console.warn("Please enter valid Number!!");


// console.time("Time:");
// for (let index = 0; index < 1000; index++) {
//     console.log(index);
// }
// console.timeEnd("Time :");