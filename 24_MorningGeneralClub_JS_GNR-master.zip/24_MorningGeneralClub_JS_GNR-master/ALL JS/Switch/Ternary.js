// Ternary Operator :

// var Age = 21;

// 5 milk   5-20 Tea 20> Coffee 
// var product;

// if(Age<5)
// {
//     product = "Milk";
// }
// else if(Age>=5 && Age<20)
// {
//     product = "Tea";
// }
// else{
//     product = "Coffee";
// }
// console.log(product);


// Syntax :    (condition)? code1 : code2;

// var Age = 20;

// var product = (Age<5)?  "Milk" : ((Age>=5 && Age<20)? "Tea" : "Coffee");

// console.log(product);
