// console.log("Hello Everyone");
// console.log("Hello Everyone");


// 1) using var :


/Number/
var num = 12.123;
console.log(num);

/String/
// var cname =  "Royal Technosoft";
var cname = 'a';
console.log(cname);

/Boolean/
var Bool = true;
console.log(Bool);


/typeof Operator :/
console.log(typeof(cname));
console.log(typeof num);


/Object/
var Arr = [1,2,3,4,5];
console.log(Arr);
console.log(typeof Arr);

var v1 = null;
console.log(v1);
console.log(typeof v1);

var obj = {
    fname : "Raj",
    lname : "Patel"
};
console.log(obj);
console.log(typeof obj);


/undefined/
var v2 = undefined;
console.log(v2);
console.log(typeof v2);
