/Rule for Variable name : / 

//1) we can start with char : 
// var cname = "asdf";
// console.log(cname);


//2) we can use number in a variable name 
// var n1 = 123;
// console.log(n1);

// 3) But we cann't use number variable name starting point :
// var 1n = 123;//invalid

//4) we can use uppercase lowecase combinaton 
// var Cname = "sdf";

//5) we cann't use special char in a variable name (but we can use :  '_' , '$')

// var _cname1 = "1234";//valid
// var $cname1 = "1234";//valid
// var %cname1 = "1234"; // invalid

// console.log($cname1)

//6) we cann't use blankspace between variable name : 
// var cname 1 = 12;//invalid

//7) JS case sensetive 

// var cname = "Raj";
// var Cname = "Ajay";
// console.log(Cname);

//8) we cann't use keyword in a Variable name : 
// var var = 2;//invalid

// var log = 12;
// console.log(log);

// var name = "asd";
// console.log(name);


//https://www.javaguides.net/2023/07/javascript-variables-quiz.html