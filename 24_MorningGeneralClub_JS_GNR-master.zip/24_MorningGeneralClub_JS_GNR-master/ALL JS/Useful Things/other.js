//    ✅ Null, undefined, BigInt, typeof.
//    ✅ Booleans and Comparison Operator.
//    ✅ Truthy and Falsy Values.


// alert("asd\n\t\tfg");

// var n1 = "Z";
// var n2 = 2;

// //NaN== Not a Number

// console.log(n1+n2);
// console.log(n1-n2);//NaN
// console.log(n1*n2);//NaN
// console.log(n1/n2);//NaN


// console.log(Boolean(0));

///////////////////////////////////////////////////
// var n1 = null;
// var n2 = undefined; //n1 string 
// console.log(typeof n1);
// console.log(typeof n2); 


// var n1 = 12n;
// // console.log(typeof n1);

// var n2 = 12;
// console.log(n1+BigInt(n2));



//////////////////////////
//Truthy Value 
// true,1,112.3,[1,2,3],"asdfg",{key1:""},12n,0.00000001

// Falsy Value 
// false,0,"",null,NaN,undefined