// - Clone array & spread operator.

// var Arr1 = [1,2,3,4];
// //1) concat() Method 
// var Arr2 = Arr1.concat();

// console.log("Value of Arr1 : ",Arr1);
// console.log("Value of Arr2 : ",Arr2);

// Arr1.push(100);

// Arr2.push(200,300);
// console.log("Value of Arr1 : ",Arr1);
// console.log("Value of Arr2 : ",Arr2);

// 2)  slice() Method 

// var Arr1 = [1,2,3];
//             //starting index ,ending 
// var Arr2 = Arr1.slice(1,3);
// // var Arr2 = Arr1.slice(0,Arr1.length);


// console.log("Value of Arr1 : ",Arr1);
// console.log("Value of Arr2 : ",Arr2);

// Arr1.push(100);

// console.log("Value of Arr1 : ",Arr1);
// console.log("Value of Arr2 : ",Arr2);




// wap to create clone same values in Array. 
// arr = [1,2,3,2,2,17,4,6,7,4,8]

// cloneArr = [2,2,2,4,4];
