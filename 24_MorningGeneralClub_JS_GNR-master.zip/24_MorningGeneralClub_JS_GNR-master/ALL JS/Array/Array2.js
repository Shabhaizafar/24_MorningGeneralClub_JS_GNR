// - Primitive vs reference data types.

var n1 = 12;
var n2 = n1;
console.log("Value of N1 : ",n1);//12
console.log("Value of N2 : ",n2);//12

n1++;

console.log("Value of N1 after inc : ",n1);//13
console.log("Value of N2 after inc : ",n2);//12 //


////////////////////////////////////////////////// 
// var Arr1 = [1,2,3];
// var Arr2 = Arr1;

// console.log("Value of Arr1 : ",Arr1);//[1,2,3]
// console.log("Value of Arr2 : ",Arr2);//[1,2,3]

// Arr1.push(100);


// Arr2.push(200,300);
// console.log("Value of Arr1 after push : ",Arr1);//[1,2,3,100]
// console.log("Value of Arr2 after push : ",Arr2);//[1,2,3,100]
///////////////////////////////////////////////////////////////////////
