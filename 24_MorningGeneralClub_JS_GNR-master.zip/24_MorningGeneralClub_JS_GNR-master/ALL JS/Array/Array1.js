// - Intro to arrays.
    //  - Collection of Multiple Values with different or same Data type 
    //  - index based 
    //  - []  -> Array Bracket
// - Push pop shift unshift.

//length   1 2 3 4 5
// var Arr = [1,2,3,4,5,1,3,4,6,7,8];
// //index    0 1 2 3 4
// // console.log(Arr);//[1,2,3,4,5]
// // console.log(typeof Arr);//object
// // console.log(Array.isArray(Arr)); //true


// console.log(Arr.length);

// // console.log(Arr[3]);
// console.log(Arr[Arr.length-1]);


/Basic Methods of Array/  
var Arr = [1,2,3,4];
console.log(Arr);
//1) push :  Add new Element in based Last Index
// Arr.push(200);
// console.log(Arr);

// Arr.push(200,300,400);
// console.log(Arr);
///////////////////////////////////////////////
//2) pop : remove Element in based Last Index

// Arr.pop();
// console.log(Arr);
///////////////////////////////////////////////////
//3) shift : remove Element in based Starting Index

// Arr.shift();
// console.log(Arr);

//////////////////////////////////////////////////
//4) unshift : 
// Arr.unshift(200,400,500);
// console.log(Arr);

//////////////////////////////////////////////////////

// ///////////////////
// 1) Create an Array with diffrent Data type and print All values.
// 2) Add new Element last postion using push and print an Array.
// 3) Add new Element starting position using unshft and print an array.
// 4) remove 2 values starting and ending index