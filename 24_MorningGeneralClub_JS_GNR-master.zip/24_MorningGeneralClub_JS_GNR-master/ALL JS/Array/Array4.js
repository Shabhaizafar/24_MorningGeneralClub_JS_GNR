// - Clone array with spread operator(...) :

// var Arr1 = [1,2,3]; 

// var Arr2 = [...Arr1];


// console.log(Arr1);
// console.log(Arr2);

////////////////////////////////////////
var Arr = [11,2,3,4,5,6,7,8,9];
//    - For loop.(Basic)
// for (let i = 0; i < Arr.length; i++) {
//     // console.log("Index : ",i,"Value : ",Arr[i]);
//     console.log(`Index : ${i},Value : ${Arr[i]}`);
// }
//    - While loop in array.
// let i=0;
// while (i<Arr.length) {
//     console.log(`Index : ${i},Value : ${Arr[i]}`);
//     i++;
// }

//    - foreach Loop
// Arr.forEach((values,index,a) => {
//     console.log(values,index,a);
// });

//    - For of loop.
// for (var i of Arr) {
//     console.log(i);
// }
//    - For in loop.
// for (var j in Arr) {
//     if(j>4)
//         {
//         console.log(j,Arr[j]);
//         // console.log(j);
//     }
// }