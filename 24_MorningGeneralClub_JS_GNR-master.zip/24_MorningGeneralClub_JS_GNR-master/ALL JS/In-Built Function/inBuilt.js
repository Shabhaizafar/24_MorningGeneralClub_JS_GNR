// var fname = "Raj";

// console.log(fname);


// 1) prompt() :    
//use : take a input form the user.

// var fname = prompt("Enter your Name : ");
// var lname = prompt("Enter your LName : ");
// console.log(fname,lname);

// alert(`Your First name is ${fname}.\nYour Lastname is ${lname}.`);

//2) alert();

// var ans = alert("Hello");
// console.log(ans);

// 3) confirm()

// var ans = confirm("Are you  Aready ???");
// console.log(ans);
