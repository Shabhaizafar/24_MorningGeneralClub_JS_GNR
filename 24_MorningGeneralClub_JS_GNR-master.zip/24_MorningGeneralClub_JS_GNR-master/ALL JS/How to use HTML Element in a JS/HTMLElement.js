// main screen
document.write("<i>Hello</i>");
document.write("<br>Everyone");
document.write("<h1>HTML</h1>");


// console screen :  

console.log("Hello");
console.log("Everyone");